import React, { Component, Fragment } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import firebase from './firebase.js';






class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      accounts: [],
      
      users: [],
      title:[],
    }
  }

  componentDidMount() {
    const accountRef =  firebase.database().ref('accounts');
    accountRef.on('value', (snapshot) => {
      let accounts = snapshot.val();
      let newState = [];
      for (let info in accounts) {
        newState.push({
          id:info,
         title:accounts[info].title
                  
        })
      }
      this.setState({
        accounts:newState,
      })
    })
    const userRef = firebase.database().ref('users');
    userRef.on('value', (snapshot) => {
      let users =  snapshot.val();
      let newUserState = [];
      for (let data in users) {
        newUserState.push({
          id:data,
          username:users[data].account,
          name: users[data].name,
        })
        
      }
      this.setState({
        users: newUserState,
      })
    })
  }
  

  render() {
    return (
      <Fragment >
      <section>
        <div>
          <h2>User Name</h2>
            {this.state.users.map( data =>
            <div key={data.id}>
              <ul>
            <li >{data.name} | {data.username}</li>
               </ul>
                </div>
              
            )}
        </div>
        <div>
          <h2>User Apps</h2>
            {this.state.accounts.map( info =>
            <div key={info.id}>
             {console.log(info.title)}
              <h4 >{info.id}</h4>
             </div>
              
            )}
        </div>
      </section>  
      
        
      </Fragment>
    );
  }
}
export default App;
